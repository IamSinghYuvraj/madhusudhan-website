'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import BlogPostCard from '../../../components/BlogPostCard';
import Pagination from '../../../components/Pagination';
import { Button } from '../../../components/ui/button';
import { Badge } from '../../../components/ui/badge';
import { Loader2, ArrowLeft, Tag } from 'lucide-react';

interface Category {
  _id: string;
  name: string;
  slug: string;
}

interface BlogPost {
  _id: string;
  title: string;
  slug: string;
  excerpt?: string;
  author: {
    name: string;
    email: string;
  };
  category: {
    name: string;
    slug: string;
  };
  publishedDate: string;
}

interface CategoryPageResponse {
  category: Category;
  posts: BlogPost[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
}

export default function CategoryPage() {
  const params = useParams();
  const [data, setData] = useState<CategoryPageResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    if (params.slug) {
      fetchCategoryPosts(params.slug as string, currentPage);
    }
  }, [params.slug, currentPage]);

  const fetchCategoryPosts = async (slug: string, page: number = 1) => {
    try {
      setLoading(true);
      const response = await fetch(`/api/categories/${slug}?page=${page}&limit=9`);
      const result: CategoryPageResponse = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Category not found');
      }

      setData(result);
      setError('');
    } catch (error: any) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (loading && !data) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="flex items-center space-x-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          <span className="text-gray-600">Loading category...</span>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Category Not Found</h1>
          <p className="text-gray-600 mb-6">
            {error || 'The category you are looking for does not exist.'}
          </p>
          <Link href="/">
            <Button>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Navigation */}
      <div className="mb-6">
        <Link href="/">
          <Button variant="outline" size="sm">
            <ArrowLeft className="h-4 w-4 mr-2" />
            All Posts
          </Button>
        </Link>
      </div>

      {/* Category Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center mb-4">
          <Tag className="h-8 w-8 text-blue-600 mr-3" />
          <Badge variant="secondary" className="text-lg px-4 py-2">
            {data.category.name}
          </Badge>
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Posts in {data.category.name}
        </h1>
        <p className="text-xl text-gray-600">
          {data.pagination.total} post{data.pagination.total === 1 ? '' : 's'} found
        </p>
      </div>

      {/* Posts Grid */}
      {loading ? (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          <span className="ml-2 text-gray-600">Loading posts...</span>
        </div>
      ) : data.posts.length > 0 ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {data.posts.map((post) => (
              <BlogPostCard key={post._id} post={post} />
            ))}
          </div>

          <Pagination
            currentPage={currentPage}
            totalPages={data.pagination.pages}
            onPageChange={handlePageChange}
          />
        </>
      ) : (
        <div className="text-center py-12">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            No posts in this category yet
          </h3>
          <p className="text-gray-600 mb-6">
            Be the first to create a post in the {data.category.name} category.
          </p>
          <Link href="/">
            <Button variant="outline">
              Browse Other Categories
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}