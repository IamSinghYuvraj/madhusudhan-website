import { NextRequest, NextResponse } from 'next/server';
import connectDB from '../../../../lib/mongodb';
import BlogPost from '../../../../models/BlogPost';
import Category from '../../../../models/Category';

export async function GET(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    await connectDB();

    const category = await Category.findOne({ slug: params.slug });
    if (!category) {
      return NextResponse.json(
        { error: 'Category not found' },
        { status: 404 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');

    const skip = (page - 1) * limit;

    const posts = await BlogPost.find({ category: category._id })
      .populate('author', 'name email')
      .populate('category', 'name slug')
      .sort({ publishedDate: -1 })
      .skip(skip)
      .limit(limit);

    const total = await BlogPost.countDocuments({ category: category._id });

    return NextResponse.json({
      category,
      posts,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get category posts error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch category posts' },
      { status: 500 }
    );
  }
}