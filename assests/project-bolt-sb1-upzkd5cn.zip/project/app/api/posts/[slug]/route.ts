import { NextRequest, NextResponse } from 'next/server';
import connectDB from '../../../../lib/mongodb';
import BlogPost from '../../../../models/BlogPost';

export async function GET(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    await connectDB();

    const post = await BlogPost.findOne({ slug: params.slug })
      .populate('author', 'name email')
      .populate('category', 'name slug');

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ post });
  } catch (error) {
    console.error('Get post error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch post' },
      { status: 500 }
    );
  }
}