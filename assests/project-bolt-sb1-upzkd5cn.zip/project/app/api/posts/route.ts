import { NextRequest, NextResponse } from 'next/server';
import connectDB from '../../../lib/mongodb';
import BlogPost from '../../../models/BlogPost';

export async function GET(request: NextRequest) {
  try {
    await connectDB();

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search') || '';

    const skip = (page - 1) * limit;

    let query = {};
    if (search) {
      query = {
        title: { $regex: search, $options: 'i' }
      };
    }

    const posts = await BlogPost.find(query)
      .populate('author', 'name email')
      .populate('category', 'name slug')
      .sort({ publishedDate: -1 })
      .skip(skip)
      .limit(limit);

    const total = await BlogPost.countDocuments(query);

    return NextResponse.json({
      posts,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get posts error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch posts' },
      { status: 500 }
    );
  }
}