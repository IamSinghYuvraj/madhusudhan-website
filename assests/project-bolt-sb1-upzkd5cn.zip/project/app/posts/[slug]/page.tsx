'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '../../../components/ui/button';
import { Badge } from '../../../components/ui/badge';
import { Separator } from '../../../components/ui/separator';
import { Loader2, ArrowLeft, User, Calendar, Tag } from 'lucide-react';
import { format } from 'date-fns';

interface BlogPost {
  _id: string;
  title: string;
  slug: string;
  content: string;
  author: {
    name: string;
    email: string;
  };
  category: {
    name: string;
    slug: string;
  };
  publishedDate: string;
  createdAt: string;
  updatedAt: string;
}

export default function PostDetailPage() {
  const params = useParams();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (params.slug) {
      fetchPost(params.slug as string);
    }
  }, [params.slug]);

  const fetchPost = async (slug: string) => {
    try {
      const response = await fetch(`/api/posts/${slug}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Post not found');
      }

      setPost(data.post);
    } catch (error: any) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="flex items-center space-x-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          <span className="text-gray-600">Loading post...</span>
        </div>
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Post Not Found</h1>
          <p className="text-gray-600 mb-6">
            {error || 'The post you are looking for does not exist or has been removed.'}
          </p>
          <Link href="/">
            <Button>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Navigation */}
      <div className="mb-8">
        <Link href="/">
          <Button variant="outline" size="sm">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Posts
          </Button>
        </Link>
      </div>

      {/* Post Header */}
      <article className="prose prose-lg max-w-none">
        <header className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 leading-tight mb-6">
            {post.title}
          </h1>
          
          <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-6">
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4" />
              <span>{post.author.name}</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4" />
              <span>{format(new Date(post.publishedDate), 'MMMM dd, yyyy')}</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <Tag className="h-4 w-4" />
              <Link href={`/categories/${post.category.slug}`}>
                <Badge variant="secondary" className="hover:bg-blue-100 transition-colors">
                  {post.category.name}
                </Badge>
              </Link>
            </div>
          </div>
          
          <Separator className="mb-8" />
        </header>

        {/* Post Content */}
        <div className="prose prose-lg max-w-none text-gray-800 leading-relaxed">
          {post.content.split('\n').map((paragraph, index) => (
            <p key={index} className="mb-6 text-justify">
              {paragraph}
            </p>
          ))}
        </div>

        {/* Post Footer */}
        <footer className="mt-12 pt-8 border-t">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="text-sm text-gray-600">
              Published on {format(new Date(post.publishedDate), 'MMMM dd, yyyy')} by {post.author.name}
            </div>
            
            <div className="flex items-center space-x-4">
              <Link href={`/categories/${post.category.slug}`}>
                <Button variant="outline" size="sm">
                  More in {post.category.name}
                </Button>
              </Link>
            </div>
          </div>
        </footer>
      </article>
    </div>
  );
}