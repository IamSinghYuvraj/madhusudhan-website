'use client';

import React from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { User, Calendar, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';

interface BlogPostCardProps {
  post: {
    _id: string;
    title: string;
    slug: string;
    excerpt?: string;
    author: {
      name: string;
      email: string;
    };
    category: {
      name: string;
      slug: string;
    };
    publishedDate: string;
  };
}

const BlogPostCard: React.FC<BlogPostCardProps> = ({ post }) => {
  return (
    <Card className="h-full hover:shadow-lg transition-all duration-300 border-0 shadow-sm hover:shadow-xl">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between gap-4">
          <CardTitle className="text-xl font-semibold leading-tight text-gray-900 line-clamp-2">
            <Link 
              href={`/posts/${post.slug}`}
              className="hover:text-blue-600 transition-colors"
            >
              {post.title}
            </Link>
          </CardTitle>
          <Badge variant="secondary" className="shrink-0">
            <Link 
              href={`/categories/${post.category.slug}`}
              className="hover:underline"
            >
              {post.category.name}
            </Link>
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        {post.excerpt && (
          <p className="text-gray-600 mb-6 line-clamp-3 leading-relaxed">
            {post.excerpt}
          </p>
        )}
        
        <div className="flex items-center justify-between">
          <div className="flex flex-col space-y-2 text-sm text-gray-500">
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4" />
              <span>{post.author.name}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4" />
              <span>{format(new Date(post.publishedDate), 'MMM dd, yyyy')}</span>
            </div>
          </div>
          
          <Link href={`/posts/${post.slug}`}>
            <button className="inline-flex items-center space-x-1 text-blue-600 hover:text-blue-700 font-medium text-sm transition-colors">
              <span>Read more</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

export default BlogPostCard;