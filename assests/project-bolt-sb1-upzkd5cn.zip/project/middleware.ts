import { withAuth } from 'next-auth/middleware';
import { NextResponse } from 'next/server';

export default withAuth(
  function middleware(req) {
    const { pathname } = req.nextUrl;
    const token = req.nextauth.token;

    // Allow access to public routes
    const publicRoutes = ['/', '/login', '/register', '/posts', '/categories'];
    const isPublicRoute = publicRoutes.some(route => 
      pathname === route || 
      pathname.startsWith('/posts/') || 
      pathname.startsWith('/categories/') ||
      pathname.startsWith('/api/posts') ||
      pathname.startsWith('/api/categories') ||
      pathname.startsWith('/api/auth')
    );

    // If it's a public route, allow access
    if (isPublicRoute) {
      return NextResponse.next();
    }

    // If user is not authenticated and trying to access protected route
    if (!token) {
      const loginUrl = new URL('/login', req.url);
      loginUrl.searchParams.set('callbackUrl', pathname);
      return NextResponse.redirect(loginUrl);
    }

    return NextResponse.next();
  },
  {
    callbacks: {
      authorized: ({ token, req }) => {
        const { pathname } = req.nextUrl;
        
        // Allow access to public routes without token
        const publicRoutes = ['/', '/login', '/register', '/posts', '/categories'];
        const isPublicRoute = publicRoutes.some(route => 
          pathname === route || 
          pathname.startsWith('/posts/') || 
          pathname.startsWith('/categories/') ||
          pathname.startsWith('/api/posts') ||
          pathname.startsWith('/api/categories') ||
          pathname.startsWith('/api/auth')
        );

        if (isPublicRoute) {
          return true;
        }

        // For protected routes, require authentication
        return !!token;
      },
    },
  }
);

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    '/((?!_next/static|_next/image|favicon.ico|public/).*)',
  ],
};